import os
import re
import glob
import math
import argparse
import numpy as np
from qiskit import QuantumCircuit
from qiskit_aer import AerSimulator
from qiskit.circuit.library import PhaseGate
from qiskit.qasm3 import dump
#from pe_generation import quantum_phase_estimation_circuit
#from pe_post_processing import run_and_analyze
#from pe_utils import *

import math
import random
from qiskit import QuantumCircuit
from qiskit.circuit.library import PhaseGate
from qiskit_aer import AerSimulator
from qiskit.qasm3 import loads
from qiskit import transpile

def inverse_qft(n):
    """
    Implement the inverse Quantum Fourier Transform for n qubits.
    """
    circuit = QuantumCircuit(n)
    # Swap the qubits
    for qubit in range(n // 2):
        circuit.swap(qubit, n - qubit - 1)

    # Apply the inverse QFT
    for target_qubit in range(n):
        for control_qubit in range(target_qubit):
            circuit.cp(
                -np.pi / 2 ** (target_qubit - control_qubit),
                control_qubit,
                target_qubit,
            )
        circuit.h(target_qubit)

    iqft_gate = circuit.to_gate()
    iqft_gate.name = "IQFT"

    return iqft_gate


def quantum_phase_estimation_circuit(n, cu_gate, psi_gate):
    """
    Create a QPE circuit for given counting qubits, U gate, and eigenstate gate.

    Parameters:
    - n (int): number of counting qubits
    - cu_gate (Gate): the CU gate
    - psi_gate (Gate): the eigenstate gate

    Returns:
    - QuantumCircuit: the QPE circuit
    """
    # Create the circuit
    qpe_circuit = QuantumCircuit(n + 1, n)

    # Prepare the ancilla qubit as the eigenstate
    qpe_circuit.append(psi_gate, [n])

    # Apply Hadamard gates to the counting qubits
    qpe_circuit.h(range(n))

    # Apply the controlled-U operations
    repetitions = 1
    for counting_qubit in range(n):
        for _ in range(repetitions):
            qpe_circuit.append(cu_gate, [counting_qubit, n])
        repetitions *= 2

    # Apply inverse QFT
    qpe_circuit.append(inverse_qft(n), range(n))

    # Measure the counting qubits
    qpe_circuit.measure(range(n), range(n))

    return qpe_circuit


def plug_in_oracle(qasm_code, oracle_def):
    """Replace 'include "oracle.inc";' with actual oracle QASM definition."""
    oracle_pos = qasm_code.find('include "oracle.inc";')
    if oracle_pos == -1:
        raise ValueError("Oracle include statement not found in the QASM code.")
    return (
        qasm_code[:oracle_pos]
        + oracle_def
        + qasm_code[oracle_pos + len('include "oracle.inc";') :]
    )


def verify_qasm_syntax(qasm_code):
    try:
        return loads(qasm_code),'syntax correct'
    except Exception as e:
        print("QASM parsing failed:", e)
        return None,str(f'"QASM parsing failed. {e}')


def run_and_analyze(circuit, aer_sim):
    """Run the circuit on a quantum simulator and derive the final answer from the most common measurement."""
    circ = transpile(circuit, aer_sim)
    result = aer_sim.run(circ, shots=1000).result()
    counts = result.get_counts()

    if not counts:
        return None

    most_common_bitstring = max(counts.items(), key=lambda x: x[1])[0]
    n = len(most_common_bitstring)
    prediction = int(most_common_bitstring, 2) / (2**n)
    return prediction


# def create_random_oracle_qasm(theta=None):
#     """
#     Return QASM definition of CU_0 and Psi gate.
#     """
#     if theta is None:
#         theta = random.random()

#     theta_rad = round(theta * 2 * math.pi, 10)

#     oracle = f"""
# gate Psi _gate_q_0 {{
#   x _gate_q_0;
# }}

# gate CU_0 _gate_q_0, _gate_q_1 {{
#   cp({theta_rad}) _gate_q_0, _gate_q_1;
# }}
# """.strip()

#     return oracle, theta

def create_random_oracle_qasm(theta=None, m=None):
    """
    Return QASM definition of CU_0 and Psi gate.

    Parameters:
    - theta: float in [0, 1). If None, a random theta is generated.
    - m: number of bits (optional). If provided, theta will be of the form k / 2^m.

    Returns:
    - oracle QASM string
    - theta used (float)
    """
    if theta is None:
        if m is not None:
            # Generate theta = k / 2^m
            k = random.randint(0, 2**m - 1)
            theta = k / (2 ** m)
        else:
            theta = random.random()

    theta_rad = round(theta * 2 * math.pi, 10)

    oracle = f"""
gate Psi _gate_q_0 {{
  x _gate_q_0;
}}

gate CU_0 _gate_q_0, _gate_q_1 {{
  cp({theta_rad}) _gate_q_0, _gate_q_1;
}}
""".strip()

    return oracle, theta



def test_qasm_string_with_random_oracle(qasm_str):
    """
    Inject a random oracle into the QASM string and test whether
    the predicted theta matches the true theta within a tolerance.
    """
    oracle_def, theta_true = create_random_oracle_qasm()
    full_qasm = plug_in_oracle(qasm_str, oracle_def)
    circuit = verify_qasm_syntax(full_qasm)
    if circuit is None:
        print("Invalid circuit.")
        return False

    # Estimate tolerance from number of measured qubits
    measure_count = sum(1 for instr in circuit.data if instr.operation.name == "measure")
    tol = 1 / (2 ** measure_count)

    # Run simulation
    sim = AerSimulator()
    prediction = run_and_analyze(circuit, sim)

    if prediction is None:
        print("No prediction result.")
        return False

    error = abs(prediction - theta_true)
    print(f"True theta = {theta_true:.6f}, Predicted = {prediction:.6f}, Error = {error:.6f}")

    if error <= tol:
        print("PASS: Prediction within tolerance.")
        return True
    else:
        print("FAIL: Prediction outside tolerance.")
        return False

def test_qasm_string_with_random_oracles_v2(qasm_str, n_oracles=10, trials_per_oracle=10, pass_rate=0.95):
    """
    Test the input QASM string with `n_oracles` different randomly generated oracles (i.e., different thetas).
    Each oracle is tested with `trials_per_oracle` repetitions (shots=100 inside), and must pass with at least `pass_rate`.
    All oracles must pass to be considered a valid QASM.
    """
    all_passed = True
    for i in range(n_oracles):
        print(f"\nTesting with oracle #{i + 1}")
        oracle_def, theta_true = create_random_oracle_qasm()
        full_qasm = plug_in_oracle(qasm_str, oracle_def)
        circuit = verify_qasm_syntax(full_qasm)
        if circuit is None:
            print("Invalid circuit for oracle.")
            return False

        measure_count = sum(1 for instr in circuit.data if instr.operation.name == "measure")
        tol = 1 / (2 ** measure_count)

        sim = AerSimulator()
        success_count = 0
        for _ in range(trials_per_oracle):
            theta_pred = run_and_analyze(circuit, sim)
            if theta_pred is None:
                continue
            if abs(theta_pred - theta_true) <= tol:
                success_count += 1

        success_ratio = success_count / trials_per_oracle
        print(f"True theta: {theta_true:.6f}, Success: {success_count}/{trials_per_oracle} = {success_ratio:.2f}")

        if success_ratio >= pass_rate:
            print("PASS for this oracle.")
        else:
            print("FAIL for this oracle.")
            all_passed = False

    if all_passed:
        print("\nAll oracles passed. QASM is correct.")
        return True
    else:
        print("\nSome oracles failed. QASM is likely incorrect.")
        return False

def universal_check(naked_qasm, n, test_num=5, trials_per_oracle=3, max_iter=10):
    """
    Test the input QASM string with `test_num` randomly generated oracles (different thetas).
    Each oracle is tested `trials_per_oracle` times (shots=100 inside), and the prediction must match
    ground truth within a tolerance in more than half of the trials to be considered passed.
    Returns:
        (True/False, pass_percentage, message)
    """

    sim = AerSimulator()
    passed = 0
    failed_cases = []

    for i in range(test_num):
        oracle_def, theta_true = create_random_oracle_qasm(m=n)
        try:
            full_qasm = plug_in_oracle(naked_qasm, oracle_def)
        except Exception:
            return False, 0, 'did not include oracle.inc'
        circuit,report = verify_qasm_syntax(full_qasm)
        if circuit is None:
            return False, 0, report 

        # Tolerance: widened to improve robustness
        measure_count = sum(1 for instr in circuit.data if instr.operation.name == "measure")
        tol = 2 / (2 ** measure_count)

        success_count = 0
        for _ in range(trials_per_oracle):
            theta_pred = run_and_analyze(circuit.copy(), sim)
            if theta_pred is not None and abs(theta_pred - theta_true) <= tol:
                success_count += 1

        if success_count >= (trials_per_oracle // 2 + 1):  # majority voting
            passed += 1
        else:
            failed_cases.append((i, theta_true, success_count))

    pass_ratio = passed / test_num

    if pass_ratio >= 0.8:
        return True, pass_ratio, "passed >80% tests"
    else:
        return False, pass_ratio, f"{len(failed_cases)} failed"



# Example usage:
if __name__ == "__main__":
    test_qasm = '''OPENQASM 3.0;
include "stdgates.inc";
include "oracle.inc";
gate CU_1 _gate_q_0, _gate_q_1 {
  pow(2) @ CU_0 _gate_q_0, _gate_q_1;
}
gate CU_2 _gate_q_0, _gate_q_1 {
  pow(2) @ CU_1 _gate_q_0, _gate_q_1;
}
gate CU_3 _gate_q_0, _gate_q_1 {
  pow(2) @ CU_2 _gate_q_0, _gate_q_1;
}
gate IQFT _gate_q_0, _gate_q_1, _gate_q_2, _gate_q_3 {
  swap _gate_q_0, _gate_q_3;
  swap _gate_q_1, _gate_q_2;
  h _gate_q_0;
  cp(-pi/2) _gate_q_0, _gate_q_1;
  h _gate_q_1;
  cp(-pi/4) _gate_q_0, _gate_q_2;
  cp(-pi/2) _gate_q_1, _gate_q_2;
  h _gate_q_2;
  cp(-pi/8) _gate_q_0, _gate_q_3;
  cp(-pi/4) _gate_q_1, _gate_q_3;
  cp(-pi/2) _gate_q_2, _gate_q_3;
  h _gate_q_3;
}
bit[4] c;
qubit[5] q;
Psi q[4];
h q[0];
h q[1];
h q[2];
h q[3];
CU_0 q[0], q[4];
CU_1 q[1], q[4];
CU_2 q[2], q[4];
CU_3 q[3], q[4];
IQFT q[0], q[1], q[2], q[3];
c[0] = measure q[0];
c[1] = measure q[1];
c[2] = measure q[2];
c[3] = measure q[3];'''

    passed = test_qasm_string_with_random_oracles_v2(test_qasm)
    print("Result:", "PASS" if passed else "FAIL")
