# #!/usr/bin/env python3
# """
# Universal functional tester for n-bit quantum adders given as QASM3.

# - Input circuit registers (names configurable via RegNames):
#     a[n], b[n], cin[1], cout[1]
# - Default assumption: sums are written into register 'b' (Cuccaro style).
# - The tester:
#     1) Parses QASM to a QuantumCircuit (syntax check).
#     2) For 3 random input pairs (a_val, b_val, cin_bit), prepares inputs by X-ing qubits.
#     3) Appends the adder circuit.
#     4) Measures sum register + cout into a fresh classical register.
#     5) Compares against classical addition.

# Dependencies: qiskit, qiskit-aer
# """

# import random
# from dataclasses import dataclass
# from typing import Tuple, Optional, List

# from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
# from qiskit_aer import AerSimulator
# from qiskit.qasm3 import loads as qasm3_loads


# @dataclass
# class RegNames:
#     a: str = "a"
#     b: str = "b"
#     cin: str = "cin"
#     cout: str = "cout"
#     sum_reg: str = "b"  # where sums are written; "b" for Cuccaro, change to "a" if needed


# # ---------- helpers ----------
# def _find_qreg(qc: QuantumCircuit, name: str) -> QuantumRegister:
#     for qreg in qc.qregs:
#         if qreg.name == name:
#             return qreg
#     raise ValueError(f"Quantum register '{name}' not found in circuit.")


# def _x_prep_bits(qc: QuantumCircuit, qreg: QuantumRegister, value: int, n: int) -> None:
#     # Little-endian prep: bit i of value goes to qreg[i]
#     for i in range(n):
#         if (value >> i) & 1:
#             qc.x(qreg[i])


# def _append_measure(qc: QuantumCircuit, targets: List[Tuple[QuantumRegister, int]], creg_name: str) -> ClassicalRegister:
#     """
#     Append measurements for specific (qreg, index) targets into a new classical register.
#     Order in 'targets' is LSB..MSB then cout last.
#     """
#     creg = ClassicalRegister(len(targets), creg_name)
#     qc.add_register(creg)
#     for ci, (qreg, qi) in enumerate(targets):
#         qc.measure(qreg[qi], creg[ci])
#     return creg


# def _decode_sum_and_cout_from_counts_key(bitstring: str, n: int) -> Tuple[int, int]:
#     """
#     Decode sum (n bits) and cout (1 bit) from a counts key.

#     We measured into one fresh classical register 'res' where:
#       creg[0..n-1] = sum[0..n-1]  (LSB..MSB)
#       creg[n]      = cout

#     Qiskit prints classical bits MSB-left within the creg, so the string is:
#       bitstring = [cout][sum_{n-1}]...[sum_1][sum_0]
#     """
#     if len(bitstring) < n + 1:
#         raise ValueError("Counts key shorter than expected.")

#     cout = int(bitstring[0])  # leftmost is creg[n] = cout

#     # Rightmost n bits are sum with MSB-left inside that substring.
#     # Let’s reconstruct the integer as little-endian:
#     sum_int = 0
#     for i in range(n):
#         # pick from right: bit for sum[i] lives at position -(i+1)
#         sum_int |= (int(bitstring[-(i + 1)]) << i)
#     return sum_int, cout


# def _expected_sum(a_val: int, b_val: int, cin_bit: int, n: int) -> Tuple[int, int]:
#     total = a_val + b_val + cin_bit
#     return total & ((1 << n) - 1), (total >> n) & 1


# def verify_qasm_syntax(qasm_code: str) -> Tuple[Optional[QuantumCircuit], str]:
#     try:
#         qc = qasm3_loads(qasm_code)
#         return qc, "syntax correct"
#     except Exception as e:
#         return None, f"QASM parsing failed. {e}"


# def _single_functional_trial(
#     base_qc: QuantumCircuit,
#     n_a: int,
#     n_b: int,
#     regnames: RegNames,
#     a_val: int,
#     b_val: int,
#     cin_bit: int,
#     shots: int = 1000,
# ) -> Tuple[bool, str]:
#     # Locate registers
#     a_qr = _find_qreg(base_qc, regnames.a)
#     b_qr = _find_qreg(base_qc, regnames.b)
#     cin_qr = _find_qreg(base_qc, regnames.cin)
#     cout_qr = _find_qreg(base_qc, regnames.cout)

#     if len(a_qr) < n_a or len(b_qr) < n_b or len(cin_qr) < 1 or len(cout_qr) < 1:
#         raise ValueError("Register sizes in QASM do not match provided n_a / n_b or missing cin/cout.")

#     # Build wrapper circuit sharing the same qregs as DUT
#     test_qc = QuantumCircuit(*base_qc.qregs)

#     # Prepare inputs
#     _x_prep_bits(test_qc, a_qr, a_val, n_a)
#     _x_prep_bits(test_qc, b_qr, b_val, n_b)
#     if cin_bit == 1:
#         test_qc.x(cin_qr[0])

#     # Append DUT
#     test_qc.compose(base_qc, inplace=True)

#     # Measure sum and cout
#     n = max(n_a, n_b)
#     sum_qr = _find_qreg(test_qc, regnames.sum_reg)
#     if len(sum_qr) < n:
#         raise ValueError(f"Sum register '{regnames.sum_reg}' too small for n={n}.")

#     measure_targets = [(sum_qr, i) for i in range(n)] + [(cout_qr, 0)]
#     _append_measure(test_qc, measure_targets, "res")

#     # Simulate
#     sim = AerSimulator()
#     job = sim.run(transpile(test_qc, sim), shots=shots)
#     counts = job.result().get_counts()

#     # Most frequent outcome
#     winner = max(counts.items(), key=lambda kv: kv[1])[0]
#     sum_meas, cout_meas = _decode_sum_and_cout_from_counts_key(winner, n)

#     exp_sum, exp_cout = _expected_sum(a_val, b_val, cin_bit, n)
#     passed = (sum_meas == exp_sum) and (cout_meas == exp_cout)

#     detail = (f"[a={a_val:0{n_a}b} b={b_val:0{n_b}b} cin={cin_bit}]  "
#               f"meas(sum={sum_meas:0{n}b}, cout={cout_meas})  "
#               f"exp(sum={exp_sum:0{n}b}, cout={exp_cout})  "
#               f"{'PASS' if passed else 'FAIL'}")
#     return passed, detail


# def universal_check(
#     qasm_string: str,
#     n_a: int,
#     n_b: int,
#     shots: int = 1000,
#     trials: int = 8,
#     regnames: RegNames = RegNames(),
#     rng_seed: Optional[int] = None,
# ) -> Tuple[bool, float, str]:
#     """
#     Returns (syntax_ok, score, report_text)
#       - syntax_ok: False if QASM parsing fails
#       - score: fraction of functional tests passed (0..1), or 0 if syntax failed
#       - report_text: multi-line string with details
#     """
#     report_lines: List[str] = []

#     qc, rep = verify_qasm_syntax(qasm_string)
#     report_lines.append(f"Syntax: {rep}")
#     if qc is None:
#         return (False, 0.0, "\n".join(report_lines))

#     if rng_seed is not None:
#         random.seed(rng_seed)

#     if n_a <= 0 or n_b <= 0:
#         report_lines.append("Error: n_a and n_b must be positive.")
#         return (True, 0.0, "\n".join(report_lines))

#     n = max(n_a, n_b)

#     passes = 0
#     for t in range(trials):
#         a_val = random.randint(0, (1 << n_a) - 1)
#         b_val = random.randint(0, (1 << n_b) - 1)
#         cin_bit = random.randint(0, 1)

#         try:
#             ok, detail = _single_functional_trial(
#                 qc, n_a, n_b, regnames, a_val, b_val, cin_bit, shots=shots
#             )
#             report_lines.append(f"Trial {t+1}: {detail}")
#             if ok:
#                 passes += 1
#         except Exception as e:
#             report_lines.append(f"Trial {t+1}: ERROR: {e}")

#     score = passes / max(1, trials)
#     overall = "Functional check PASSED" if passes == trials else ("Functional check PARTIAL" if passes > 0 else "Functional check FAILED")
#     report_lines.append(f"Summary: {passes}/{trials} passed  |  score={score:.2f}  |  shots={shots}")
#     return (True, score, f"{overall}\n" + "\n".join(report_lines))


# # ------------- example: your n=4 Cuccaro/MAJ-UMA QASM -------------
# if __name__ == "__main__":
#     qasm_string = '''
# OPENQASM 3.0;
# include "stdgates.inc";
# gate MAJ _gate_q_0, _gate_q_1, _gate_q_2 {
#   cx _gate_q_0, _gate_q_1;
#   cx _gate_q_0, _gate_q_2;
#   ccx _gate_q_2, _gate_q_1, _gate_q_0;
# }
# gate UMA _gate_q_0, _gate_q_1, _gate_q_2 {
#   ccx _gate_q_2, _gate_q_1, _gate_q_0;
#   cx _gate_q_0, _gate_q_2;
#   cx _gate_q_2, _gate_q_1;
# }
# gate FullAdder _gate_q_0, _gate_q_1, _gate_q_2, _gate_q_3, _gate_q_4, _gate_q_5, _gate_q_6, _gate_q_7, _gate_q_8, _gate_q_9, _gate_q_10, _gate_q_11 {
#   MAJ _gate_q_1, _gate_q_6, _gate_q_0;
#   MAJ _gate_q_2, _gate_q_7, _gate_q_1;
#   MAJ _gate_q_3, _gate_q_8, _gate_q_2;
#   MAJ _gate_q_4, _gate_q_9, _gate_q_3;
#   MAJ _gate_q_5, _gate_q_10, _gate_q_4;
#   cx _gate_q_5, _gate_q_11;
#   UMA _gate_q_5, _gate_q_10, _gate_q_4;
#   UMA _gate_q_4, _gate_q_9, _gate_q_3;
#   UMA _gate_q_3, _gate_q_8, _gate_q_2;
#   UMA _gate_q_2, _gate_q_7, _gate_q_1;
#   UMA _gate_q_1, _gate_q_6, _gate_q_0;
# }
# qubit[5] a;
# qubit[5] b;
# qubit[1] cin;
# qubit[1] cout;
# FullAdder a[0], a[1], a[2], a[3], a[4], b[0], b[1], b[2], b[3], b[4], cin[0], cout[0];
# '''

#     ok, score, report = universal_check(
#         qasm_string=qasm_string,
#         n_a=5,
#         n_b=5,
#         shots=1000,
#         trials=32,
#         regnames=RegNames(sum_reg="b")
#     )
#     print(ok, score)
#     print(report)


#================================

#!/usr/bin/env python3
"""
Universal checker for your fixed-format adder QASM (OpenQASM 3.0).

Assumptions (fixed by your format):
  - Registers: a[n], b[n], cin[1], cout[1]
  - Sums are written into register 'b'
  - Carry-in bit is cin[0]
  - Carry-out is cout[0]

Default: shots=1000, trials=3.
"""

import random
from typing import Tuple, Optional, List

from qiskit import QuantumCircuit, QuantumRegister, ClassicalRegister, transpile
from qiskit_aer import AerSimulator
from qiskit.qasm3 import loads as qasm3_loads


# ---------------- helpers ----------------

def _find_qreg(qc: QuantumCircuit, name: str) -> QuantumRegister:
    for qreg in qc.qregs:
        if qreg.name == name:
            return qreg
    raise ValueError(f"Quantum register '{name}' not found in circuit.")


def _x_prep_bits(qc: QuantumCircuit, qreg: QuantumRegister, value: int, n: int) -> None:
    """Little-endian prep: bit i of value -> qreg[i]."""
    for i in range(n):
        if (value >> i) & 1:
            qc.x(qreg[i])


def _append_measure_b_and_cout(qc: QuantumCircuit, b_qr: QuantumRegister, cout_qr: QuantumRegister, n: int) -> ClassicalRegister:
    """
    Measure into a fresh creg in this order:
      creg[0..n-1] = b[0..n-1]  (sum, LSB..MSB)
      creg[n]      = cout[0]
    """
    creg = ClassicalRegister(n + 1, "res")
    qc.add_register(creg)
    for i in range(n):           # sum bits
        qc.measure(b_qr[i], creg[i])
    qc.measure(cout_qr[0], creg[n])
    return creg


def _decode_sum_and_cout_from_counts_key(bitstring: str, n: int) -> Tuple[int, int]:
    """
    With measurement order [b[0],...,b[n-1], cout] and Qiskit printing MSB-left,
    the printed string is: [cout][b[n-1]]...[b[1]][b[0]].
    """
    if len(bitstring) < n + 1:
        raise ValueError("Counts key is shorter than expected.")
    cout = int(bitstring[0])  # leftmost is cout
    s = 0
    for i in range(n):
        s |= int(bitstring[-(i + 1)]) << i  # rightmost is b[0]
    return s, cout


def _expected_sum(a_val: int, b_val: int, cin_bit: int, n: int) -> Tuple[int, int]:
    total = a_val + b_val + cin_bit
    return total & ((1 << n) - 1), (total >> n) & 1


def _simulate_and_decode(qc: QuantumCircuit, n: int, shots: int) -> Tuple[int, int]:
    sim = AerSimulator()
    tqc = transpile(qc, sim)
    result = sim.run(tqc, shots=shots).result()
    counts = result.get_counts()
    # Pick the most frequent outcome (should dominate for a deterministic adder)
    winner = max(counts.items(), key=lambda kv: kv[1])[0]
    return _decode_sum_and_cout_from_counts_key(winner, n)


# ---------------- core API ----------------

def verify_qasm_syntax(qasm_string: str) -> Tuple[Optional[QuantumCircuit], str]:
    """Parse QASM 3 and return (qc, message)."""
    try:
        qc = qasm3_loads(qasm_string)
        return qc, "syntax correct"
    except Exception as e:
        return None, f"QASM parsing failed. {e}"


def universal_check(
    qasm_string: str,
    n: int,
    *,
    shots: int = 1000,
) -> Tuple[bool, float, str]:
    """
    Fixed-format universal check for your adder QASM.

    Runs exactly 3 trials:
      1) a = 0,     b = 1,     cin = 0
      2) a = 2^(n-1), b = 0,   cin = 0
      3) a = (2^n - 1), b = (2^n - 1), cin = 1
    """
    report: List[str] = []

    # 1) syntax
    base_qc, msg = verify_qasm_syntax(qasm_string)
    report.append(f"Syntax: {msg}")
    if base_qc is None:
        return False, 0.0, "\n".join(report)

    # 2) locate regs
    try:
        a_qr = _find_qreg(base_qc, "a")
        b_qr = _find_qreg(base_qc, "b")
        cin_qr = _find_qreg(base_qc, "cin")
        cout_qr = _find_qreg(base_qc, "cout")
    except Exception as e:
        report.append(f"Register check failed: {e}")
        return False, 0.0, "\n".join(report)

    if len(a_qr) < n or len(b_qr) < n or len(cin_qr) < 1 or len(cout_qr) < 1:
        report.append("Register sizes do not match n or cin/cout missing.")
        return False, 0.0, "\n".join(report)

    # 3) fixed trials
    fixed_cases = [
        (0, 1, 0),                    # trial 1
        (1 << (n - 1), 0, 0),         # trial 2
        ((1 << n) - 1, (1 << n) - 1, 1),  # trial 3
    ]

    passes = 0
    for t, (a_val, b_val, cin_bit) in enumerate(fixed_cases, start=1):
        try:
            # Build wrapper circuit
            test_qc = QuantumCircuit(*base_qc.qregs)

            # Prepare inputs
            _x_prep_bits(test_qc, a_qr, a_val, n)
            _x_prep_bits(test_qc, b_qr, b_val, n)
            if cin_bit == 1:
                test_qc.x(cin_qr[0])

            # Append DUT
            test_qc.compose(base_qc, inplace=True)

            # Measure
            _append_measure_b_and_cout(test_qc, b_qr, cout_qr, n)

            # Simulate
            sum_meas, cout_meas = _simulate_and_decode(test_qc, n, shots)
            exp_sum, exp_cout = _expected_sum(a_val, b_val, cin_bit, n)
            ok = (sum_meas == exp_sum) and (cout_meas == exp_cout)
            if ok:
                passes += 1

            report.append(
                f"Trial {t}: [a={a_val:0{n}b} b={b_val:0{n}b} cin={cin_bit}]  "
                f"meas(sum={sum_meas:0{n}b}, cout={cout_meas})  "
                f"exp(sum={exp_sum:0{n}b}, cout={exp_cout})  "
                f"{'PASS' if ok else 'FAIL'}"
            )
        except Exception as e:
            report.append(f"Trial {t}: ERROR: {e}")

    score = passes / 3.0
    report.append(f"Summary: {passes}/3 passed  |  score={score:.2f}  |  shots={shots}")
    overall = "passed all tests" if passes == 3 else ("partially correct" if passes > 0 else "Functional check FAILED")
    if passes==3:
        return True, score, f"{overall}\n" 
    else:
        return False, score, f"{overall}\n" 

# ---------------- execution API ----------------

# universal_execute_description = """
# universal_execute(qasmstring, n, inputa, inputb, cin, shots=1000) -> (sum_int, cout_int)

# Inputs (all are regular Python values, not quantum registers):
#   - qasmstring: str
#       OpenQASM 3.0 source for an n-bit adder circuit that uses the fixed
#       register layout:
#          a[n], b[n], cin[1], cout[1]
#       and writes the SUM bits into register 'b' (Cuccaro-style).
#   - n: int
#       Bit-width of the adder. Must satisfy n >= 1.
#   - inputa: int
#       The integer value to load into register a. Must be 0 <= inputa < 2**n.
#   - inputb: int
#       The integer value to load into register b. Must be 0 <= inputb < 2**n.
#   - cin: int
#       Carry-in bit (0 or 1) to load into cin[0].
#   - shots: int (optional, default 1000)
#       Number of simulator shots. The function returns the most frequent outcome.

# Behavior:
#   1) Parses qasmstring and verifies the presence/sizes of a[n], b[n], cin[1], cout[1].
#   2) Initializes a fresh wrapper circuit sharing the DUT's quantum registers.
#   3) Encodes 'inputa' into a[0..n-1] and 'inputb' into b[0..n-1] in little-endian
#      (bit i goes to qubit [i]); sets cin[0] if cin == 1.
#   4) Composes the DUT circuit.
#   5) Measures SUM (b[0..n-1], LSB..MSB) and cout[0] into a fresh classical register.
#   6) Simulates with Aer and returns the most probable measurement.

# Output:
#   - A tuple (sum_int, cout_int) where:
#       * sum_int is the n-bit integer reconstructed from measured b[0..n-1]
#         assuming little-endian ordering (b[0] is LSB).
#       * cout_int is the measured carry-out bit (0 or 1).

# Raises:
#   - ValueError on invalid inputs (ranges/types) or when the QASM circuit is missing
#     the expected registers or sizes.
#   - Any parsing/simulation exceptions from Qiskit are propagated with context.
# """

# def universal_execute(
#     qasmstring: str,
#     n: int,
#     inputa: int,
#     inputb: int,
#     cin: int,
#     shots: int = 1000,
# ):
#     """
#     Execute the adder QASM on concrete Python integer inputs and return (sum_int, cout_int).
#     Assumes SUM is written into register 'b' and carry-out is cout[0].
#     """
#     # Basic input validation
#     if not isinstance(n, int) or n < 1:
#         raise ValueError("n must be a positive integer")
#     if not isinstance(inputa, int) or not (0 <= inputa < (1 << n)):
#         raise ValueError(f"inputa must be an int in [0, {1<<n}-1]")
#     if not isinstance(inputb, int) or not (0 <= inputb < (1 << n)):
#         raise ValueError(f"inputb must be an int in [0, {1<<n}-1]")
#     if cin not in (0, 1):
#         raise ValueError("cin must be 0 or 1")

#     # Parse QASM and locate registers
#     base_qc, msg = verify_qasm_syntax(qasmstring)
#     if base_qc is None:
#         raise ValueError(f"QASM parsing failed: {msg}")

#     a_qr = _find_qreg(base_qc, "a")
#     b_qr = _find_qreg(base_qc, "b")
#     cin_qr = _find_qreg(base_qc, "cin")
#     cout_qr = _find_qreg(base_qc, "cout")

#     if len(a_qr) < n or len(b_qr) < n or len(cin_qr) < 1 or len(cout_qr) < 1:
#         raise ValueError("Register sizes do not match n or cin/cout missing.")

#     # Build wrapper circuit
#     wrapper = QuantumCircuit(*base_qc.qregs)

#     # Prepare classical inputs (little-endian)
#     _x_prep_bits(wrapper, a_qr, inputa, n)
#     _x_prep_bits(wrapper, b_qr, inputb, n)
#     if cin == 1:
#         wrapper.x(cin_qr[0])

#     # Append DUT and measure SUM (b) + cout
#     wrapper.compose(base_qc, inplace=True)
#     _append_measure_b_and_cout(wrapper, b_qr, cout_qr, n)

#     # Simulate and decode the dominant outcome
#     sum_meas, cout_meas = _simulate_and_decode(wrapper, n, shots)
#     return (sum_meas, cout_meas)
# ---------------- execution API ----------------

universal_execute_description = """
universal_execute(qasmstring: str, n: int, inputa: str, inputb: str, cin: str) -> (sum_str: str, cout_str: str)

Purpose:
  Execute an n-bit adder circuit (OpenQASM 3.0) with fixed registers a[n], b[n], cin[1], cout[1],
  where the SUM is written into register 'b' (Cuccaro-style). Inputs and outputs are bitstrings.

Inputs (plain Python strings, NOT integers or quantum registers):
  - qasmstring: str
      OpenQASM 3.0 source that declares: a[n], b[n], cin[1], cout[1].
  - n: int
      Bit width (n >= 1).
  - inputa: str
      Bitstring of length n for register a, e.g. "0101".
      Mapping uses LSB-right: inputa[-1] -> a[0], inputa[-2] -> a[1], ... inputa[0] -> a[n-1].
  - inputb: str
      Bitstring of length n for register b (same mapping as above).
  - cin: str
      Single-bit string "0" or "1" for cin[0].

Behavior:
  1) Parses qasmstring and checks presence/sizes of a[n], b[n], cin[1], cout[1].
  2) Builds a wrapper that prepares a and b from the input bitstrings (X on '1' bits) and sets cin if "1".
  3) Composes the DUT, measures SUM (b[0..n-1]) and cout[0] into a fresh classical register.
  4) Simulates with AerSimulator for exactly 1024 shots and returns the most frequent outcome.

Output:
  - (sum_str, cout_str):
      * sum_str: n-bit string for the measured sum in MSB-left order as reported by Qiskit.
                 (This equals the rightmost n characters of the winning counts key.)
      * cout_str: "0" or "1" (the leftmost character of the winning counts key).

Errors:
  - ValueError for invalid inputs or missing/mismatched registers.
  - Qiskit parsing/simulation exceptions are propagated with context.
"""

def universal_execute(
    qasmstring: str,
    n: int,
    inputa: str,
    inputb: str,
    cin: str,
) -> (str, str):
    """
    Execute the adder QASM on bitstring inputs and return (sum_str, cout_str).
    Shots are fixed at 1024. SUM is assumed to be written in register 'b'.
    """
    # --- validate args
    if not isinstance(n, int) or n < 1:
        raise ValueError("n must be a positive integer")
    for name, s in (("inputa", inputa), ("inputb", inputb)):
        if not isinstance(s, str) or len(s) != n or any(ch not in "01" for ch in s):
            raise ValueError(f"{name} must be a bitstring of length {n}")
    if cin not in ("0", "1"):
        raise ValueError("cin must be '0' or '1'")

    # --- parse QASM & locate registers
    base_qc, msg = verify_qasm_syntax(qasmstring)
    if base_qc is None:
        raise ValueError(f"QASM parsing failed: {msg}")

    a_qr = _find_qreg(base_qc, "a")
    b_qr = _find_qreg(base_qc, "b")
    cin_qr = _find_qreg(base_qc, "cin")
    cout_qr = _find_qreg(base_qc, "cout")

    if len(a_qr) < n or len(b_qr) < n or len(cin_qr) < 1 or len(cout_qr) < 1:
        raise ValueError("Register sizes do not match n or cin/cout missing.")

    # --- build wrapper and prepare inputs (LSB-right: input[-1] -> reg[0])
    from qiskit import QuantumCircuit
    wrapper = QuantumCircuit(*base_qc.qregs)

    for i in range(n):
        if inputa[-1 - i] == "1":
            wrapper.x(a_qr[i])
        if inputb[-1 - i] == "1":
            wrapper.x(b_qr[i])
    if cin == "1":
        wrapper.x(cin_qr[0])

    # --- append DUT and measure SUM (b) + cout
    wrapper.compose(base_qc, inplace=True)
    _append_measure_b_and_cout(wrapper, b_qr, cout_qr, n)

    # --- simulate with fixed 1024 shots & decode as strings
    sim = AerSimulator()
    tqc = transpile(wrapper, sim)
    result = sim.run(tqc, shots=1024).result()
    counts = result.get_counts()

    winner = max(counts.items(), key=lambda kv: kv[1])[0]  # MSB-left string: [cout][b[n-1]]... [b[0]]
    cout_str = winner[0]
    sum_str = winner[-n:]  # rightmost n bits correspond to b[n-1]..b[0] in MSB-left order

    return sum_str, cout_str

# ---------------- example usage with your n=4 QASM ----------------

if __name__ == "__main__":
    qasm_string = '''
OPENQASM 3.0;
include "stdgates.inc";
gate MAJ _gate_q_0, _gate_q_1, _gate_q_2 {
  cx _gate_q_0, _gate_q_1;
  cx _gate_q_0, _gate_q_2;
  ccx _gate_q_2, _gate_q_1, _gate_q_0;
}
gate UMA _gate_q_0, _gate_q_1, _gate_q_2 {
  ccx _gate_q_2, _gate_q_1, _gate_q_0;
  cx _gate_q_0, _gate_q_2;
  cx _gate_q_2, _gate_q_1;
}
gate FullAdder _gate_q_0, _gate_q_1, _gate_q_2, _gate_q_3, _gate_q_4, _gate_q_5, _gate_q_6, _gate_q_7, _gate_q_8, _gate_q_9, _gate_q_10, _gate_q_11 {
  MAJ _gate_q_1, _gate_q_6, _gate_q_0;
  MAJ _gate_q_2, _gate_q_7, _gate_q_1;
  MAJ _gate_q_3, _gate_q_8, _gate_q_2;
  MAJ _gate_q_4, _gate_q_9, _gate_q_3;
  MAJ _gate_q_5, _gate_q_10, _gate_q_4;
  cx _gate_q_5, _gate_q_11;
  UMA _gate_q_5, _gate_q_10, _gate_q_4;
  UMA _gate_q_4, _gate_q_9, _gate_q_3;
  UMA _gate_q_3, _gate_q_8, _gate_q_2;
  UMA _gate_q_2, _gate_q_7, _gate_q_1;
  UMA _gate_q_1, _gate_q_6, _gate_q_0;
}
qubit[5] a;
qubit[5] b;
qubit[1] cin;
qubit[1] cout;
FullAdder a[0], a[1], a[2], a[3], a[4], b[0], b[1], b[2], b[3], b[4], cin[0], cout[0];
'''
    ok, score, report = universal_check(qasm_string, n=5)
    print(ok, score)
    print(report)
